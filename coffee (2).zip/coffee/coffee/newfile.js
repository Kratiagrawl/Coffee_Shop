document.querySelector(#menu - btn).onclick = () => {
    navbar.classList.toggle('active');
};